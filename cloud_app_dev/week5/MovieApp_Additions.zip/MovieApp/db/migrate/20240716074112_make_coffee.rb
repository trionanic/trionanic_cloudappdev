class MakeCoffee < ActiveRecord::Migration[7.1]
  def change
  end
end

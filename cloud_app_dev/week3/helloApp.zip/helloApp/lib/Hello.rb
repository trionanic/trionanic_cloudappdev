class Hello
    # say_hello is a class method. 
	def self.say_hello(name)
		result = "Hello #{name}"
	end

end

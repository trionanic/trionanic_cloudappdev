require 'hello'

class HelloController < ApplicationController

	  def hello
	  puts "CALLED hello method in the HelloController"
	  end
	  
	  def say_hello
	    puts "CALLED hello method in the HelloController"
	   @name = params[:input_name]
	   puts "The input name is " + @name.to_s
	   @result = Hello.say_hello(@name)
	   end
	  
  end

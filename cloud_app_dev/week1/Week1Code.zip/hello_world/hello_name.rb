
# Printing String to the Screen 
# Requesting input from the user
# Showing the user input data on screen 
# Implementing a variable into the return String





puts("Please enter your name")


name = gets()

puts("Hello #{name}")
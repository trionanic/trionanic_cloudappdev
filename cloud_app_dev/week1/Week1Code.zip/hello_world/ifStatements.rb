
puts("Please enter your current age to establish if you can legally drive a vechicle")
age = Integer(gets())

#age = 33

if age < 16
	puts("You are not currently of age to hold a drivers license in Ireland and therefore you cannot drive")	
else
	puts("You are of the legal age to hold a drivers license and drive a vechicle in the Republic of Ireland")
end


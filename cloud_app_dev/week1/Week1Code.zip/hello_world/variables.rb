age = 19
light_is_on = true
name = "Sean"


puts (" the users name is #{name} and they are #{age} years of age"
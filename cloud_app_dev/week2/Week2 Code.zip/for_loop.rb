# Loobs in Ruby

for i in 0...3 #remember the sequence of numbers in Computer Science 
	puts(i)
end


puts("\n\n")

repeat = 7

for i in 0...repeat
	puts(i) #Keeping a record of the amount of times repeated
	puts("Say Seven #{repeat} times")
end